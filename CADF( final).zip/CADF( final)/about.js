 // Menu mobile uniquement - JavaScript minimal
        const hamburger = document.getElementById('hamburger');
        const mobileMenu = document.getElementById('mobileMenu');
        const mobileOverlay = document.getElementById('mobileOverlay');

        function toggleMobileMenu() {
            hamburger.classList.toggle('active');
            mobileMenu.classList.toggle('active');
            mobileOverlay.classList.toggle('active');
            document.body.style.overflow = mobileMenu.classList.contains('active') ? 'hidden' : '';
        }

        function closeMobileMenu() {
            hamburger.classList.remove('active');
            mobileMenu.classList.remove('active');
            mobileOverlay.classList.remove('active');
            document.body.style.overflow = '';
        }

        // Event listeners essentiels
        hamburger.addEventListener('click', toggleMobileMenu);
        mobileOverlay.addEventListener('click', closeMobileMenu);

        // Fermer le menu mobile au clic sur un lien
        document.querySelectorAll('.mobile-nav-link').forEach(link => {
            link.addEventListener('click', closeMobileMenu);
        });

        // Fermer le menu mobile sur redimensionnement
        window.addEventListener('resize', () => {
            if (window.innerWidth > 768) {
                closeMobileMenu();
            }
        });

        // Fermer avec Escape
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && mobileMenu.classList.contains('active')) {
                closeMobileMenu();
            }
        });
        
         //changement de theme
         
 
        // les constantes 
        const btn= document.getElementById("theme-btn")
        const sun = document.getElementById("sun")
        const moon = document.getElementById("moon")
        const sauvegarde = localStorage.getItem('theme')
        
        // chargement du theme sauvegardee
        if (sauvegarde == 'dark') {
            document.documentElement.classList.add('dark')
            sun.style.display = "none"
            moon.style.display = 'inline'
        }else {
            sun.style.display = 'inline'
            moon.style.display = 'none'
               
        
            
        }
        
       // toggle de la classe dark et changement d'icones 
       btn.addEventListener("click", () => {
           if (document.documentElement.classList.contains("dark")) {
               document.documentElement.classList.remove("dark")
               sun.style.display = 'inline'
               moon.style.display = 'none'
               localStorage.setItem('theme', 'light')
           }else {
               document.documentElement.classList.add("dark")
               sun.style.display = "none"
               moon.style.display = 'inline'
               localStorage.setItem('theme', 'dark')
           }
           
           })