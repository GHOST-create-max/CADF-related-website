// Mobile Menu - JavaScript minimal
        const hamburger = document.getElementById('hamburger');
        const mobileMenu = document.getElementById('mobileMenu');
        const mobileOverlay = document.getElementById('mobileOverlay');

        function toggleMobileMenu() {
            hamburger.classList.toggle('active');
            mobileMenu.classList.toggle('active');
            mobileOverlay.classList.toggle('active');
            document.body.style.overflow = mobileMenu.classList.contains('active') ? 'hidden' : '';
        }

        function closeMobileMenu() {
            hamburger.classList.remove('active');
            mobileMenu.classList.remove('active');
            mobileOverlay.classList.remove('active');
            document.body.style.overflow = '';
        }

        hamburger.addEventListener('click', toggleMobileMenu);
        mobileOverlay.addEventListener('click', closeMobileMenu);

        document.querySelectorAll('.mobile-nav-link').forEach(link => {
            link.addEventListener('click', closeMobileMenu);
        });

        window.addEventListener('resize', () => {
            if (window.innerWidth > 768) closeMobileMenu();
        });

        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                if (mobileMenu.classList.contains('active')) closeMobileMenu();
                if (document.getElementById('imageModal').classList.contains('active')) closeModal();
            }
        });

        // Modal functionality - JavaScript essentiel pour le zoom d'image
        const imageData = {
            img1: {
                src: "images/Diapo_1.jpg",
                date: "15 Juin 2024",
                description: "Cérémonie émouvante de remise des diplômes pour nos bacheliers 2024. Un moment de fierté partagée entre élèves, familles et équipe pédagogique."
            },
            img2: {
                src: "Diapo_2.jpg",
                date: "22 Mars 2024",
                description: "Représentation exceptionnelle de 'Romeo et Juliette' par nos élèves de Première. Mise en scène remarquable et interprétations touchantes."
            },
            img3: {
                src: "images/Diapo_3.jpg",
                date: "10 Février 2024",
                description: "Concert exceptionnel de notre fanfare lors du carnaval du Cap-Haïtien. Performance qui a enthousiasmé plus de 5000 spectateurs."
            },
            img4: {
                src: "images/Diapo_4.jpg",
                date: "5 Avril 2024",
                description: "Victoire mémorable de notre équipe de football aux championnats inter-scolaires. Travail d'équipe et détermination récompensés."
            },
            img5: {
                src: "images/Diapo_5.jpg",
                date: "18 Janvier 2024",
                description: "Grande célébration du 25e anniversaire du collège. Moment historique rassemblant anciens élèves, familles et personnel éducatif."
            },
            img6: {
                src: "images/Diapo_6.jpg",
                date: "12 Avril 2024",
                description: "Élections présidentielles scolaires - exercice démocratique formateur pour nos élèves. Campagne active et participation exemplaire."
            },
            img7: {
                src: "images/Diapo_7.jpg>",
                date: "28 Février 2024",
                description: "Spectacle vibrant de danses traditionnelles haïtiennes. Nos élèves célèbrent avec fierté leur patrimoine culturel national."
            },
            img8: {
                src: "images/Diapo_8.jpg",
                date: "8 Mars 2024",
                description: "Expériences fascinantes de chimie dans notre laboratoire équipé. Science pratique et découvertes passionnantes pour nos élèves."
            },
            img9: {
                src: "images/Diapo_9.jpg",
                date: "14 Mars 2024",
                description: "Nos élèves studieux profitent de notre bibliothèque entièrement rénovée. Espace moderne propice à l'étude et à la recherche."
            },
            img10: {
                src: "images/Diapo_10.jpg",
                date: "3 Mars 2024",
                description: "Déjeuner convivial à notre cantine scolaire. Menu local équilibré et moments de partage entre élèves de toutes les classes."
            },
            img11: {
                src: "images/Diapo_11.jpg",
                date: "25 Janvier 2024",
                description: "Créativité à l'honneur dans notre atelier d'arts plastiques. Nos jeunes artistes développent leur talent et leur expression personnelle."
            },
            img12: {
                src: "images/Diapo_1.jpg>",
                date: "20 Avril 2024",
                description: "Initiation au jardinage écologique dans notre espace vert pédagogique. Sensibilisation à l'environnement et développement durable."
            }
        };

        function openModal(imageId) {
            const modal = document.getElementById('imageModal');
            const modalImage = document.getElementById('modalImage');
            const modalDate = document.getElementById('modalDate');
            const modalDescription = document.getElementById('modalDescription');
            
            const data = imageData[imageId];
            modalImage.src = data.src;
            modalImage.alt = data.description;
            modalDate.textContent = data.date;
            modalDescription.textContent = data.description;
            
            modal.classList.add('active');
            document.body.style.overflow = 'hidden';
        }

        function closeModal() {
            const modal = document.getElementById('imageModal');
            modal.classList.remove('active');
            document.body.style.overflow = '';
        }

        // Fermer modal en cliquant à l'extérieur
        document.getElementById('imageModal').addEventListener('click', function(e) {
            if (e.target === this) closeModal();
        });
        
         //changement de theme
         
 
        // les constantes 
        const btn= document.getElementById("theme-btn")
        const sun = document.getElementById("sun")
        const moon = document.getElementById("moon")
        const sauvegarde = localStorage.getItem('theme')
        
        // chargement du theme sauvegardee
        if (sauvegarde == 'dark') {
            document.documentElement.classList.add('dark')
            sun.style.display = "none"
            moon.style.display = 'inline'
        }else {
            sun.style.display = 'inline'
            moon.style.display = 'none'
               
        
            
        }
        
       // toggle de la classe dark et changement d'icones 
       btn.addEventListener("click", () => {
           if (document.documentElement.classList.contains("dark")) {
               document.documentElement.classList.remove("dark")
               sun.style.display = 'inline'
               moon.style.display = 'none'
               localStorage.setItem('theme', 'light')
           }else {
               document.documentElement.classList.add("dark")
               sun.style.display = "none"
               moon.style.display = 'inline'
               localStorage.setItem('theme', 'dark')
           }
           
           })
        
        
        