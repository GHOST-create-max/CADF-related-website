

// Mobile Menu Toggle
        const hamburger = document.getElementById('hamburger');
        const mobileMenu = document.getElementById('mobileMenu');
        const mobileOverlay = document.getElementById('mobileOverlay');
        const body = document.body;

        function toggleMobileMenu() {
            hamburger.classList.toggle('active');
            mobileMenu.classList.toggle('active');
            mobileOverlay.classList.toggle('active');
            body.style.overflow = mobileMenu.classList.contains('active') ? 'hidden' : '';
        }

        function closeMobileMenu() {
            hamburger.classList.remove('active');
            mobileMenu.classList.remove('active');
            mobileOverlay.classList.remove('active');
            body.style.overflow = '';
        }
        
 //changement de theme
         
 
        // les constantes 
        const btn= document.getElementById("theme-btn")
        const sun = document.getElementById("sun")
        const moon = document.getElementById("moon")
        const sauvegarde = localStorage.getItem('theme')
        
        // chargement du theme sauvegardee
        if (sauvegarde == 'dark') {
            document.documentElement.classList.add('dark')
            sun.style.display = "none"
            moon.style.display = 'inline'
        }else {
            sun.style.display = 'inline'
            moon.style.display = 'none'
               
        
            
        }
        
       // toggle de la classe dark et changement d'icones 
       btn.addEventListener("click", () => {
           if (document.documentElement.classList.contains("dark")) {
               document.documentElement.classList.remove("dark")
               sun.style.display = 'inline'
               moon.style.display = 'none'
               localStorage.setItem('theme', 'light')
           }else {
               document.documentElement.classList.add("dark")
               sun.style.display = "none"
               moon.style.display = 'inline'
               localStorage.setItem('theme', 'dark')
           }
           
           })
        
        
        

        // Event Listeners
        hamburger.addEventListener('click', toggleMobileMenu);
        mobileOverlay.addEventListener('click', closeMobileMenu);

        // Close mobile menu when clicking on a link
        document.querySelectorAll('.mobile-nav-link').forEach(link => {
            link.addEventListener('click', closeMobileMenu);
        });

        // Close mobile menu on window resize
        window.addEventListener('resize', () => {
            if (window.innerWidth > 768) {
                closeMobileMenu();
            }
        });

        // Scroll Animation
        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        };

        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('visible');
                }
            });
        }, observerOptions);

        // Observe all elements with fade-in class
        document.querySelectorAll('.fade-in').forEach(el => {
            observer.observe(el);
        });

        // Set active navigation link based on current page
        function setActiveNavLink() {
            const currentPage = window.location.pathname.split('/').pop() || 'index.html';
            
            // Remove active class from all links
            document.querySelectorAll('.nav-link, .mobile-nav-link').forEach(link => {
                link.classList.remove('active');
            });

            // Add active class to current page links
            document.querySelectorAll(`[href="${currentPage}"]`).forEach(link => {
                if (link.classList.contains('nav-link') || link.classList.contains('mobile-nav-link')) {
                    link.classList.add('active');
                }
            });

            // Handle index.html and root path
            if (currentPage === 'index.html' || currentPage === '') {
                document.querySelectorAll('[href="index.html"]').forEach(link => {
                    if (link.classList.contains('nav-link') || link.classList.contains('mobile-nav-link')) {
                        link.classList.add('active');
                    }
                });
            }
        }

        // Initialize on page load
        document.addEventListener('DOMContentLoaded', () => {
            setActiveNavLink();
            
            // Add smooth scrolling for anchor links
            document.querySelectorAll('a[href^="#"]').forEach(anchor => {
                anchor.addEventListener('click', function (e) {
                    e.preventDefault();
                    const target = document.querySelector(this.getAttribute('href'));
                    if (target) {
                        target.scrollIntoView({
                            behavior: 'smooth',
                            block: 'start'
                        });
                    }
                });
            });
        });

        

        // Form validation helper
        function validateForm(form) {
            const requiredFields = form.querySelectorAll('[required]');
            let isValid = true;

            requiredFields.forEach(field => {
                if (!field.value.trim()) {
                    field.style.borderColor = '#e74c3c';
                    isValid = false;
                } else {
                    field.style.borderColor = 'var(--border-color)';
                }
            });

            return isValid;
        }

        // Accessibility improvements
        document.addEventListener('keydown', (e) => {
            // Close mobile menu with Escape key
            if (e.key === 'Escape' && mobileMenu.classList.contains('active')) {
                closeMobileMenu();
            }
        });

        // Focus management for mobile menu
        mobileMenu.addEventListener('transitionend', () => {
            if (mobileMenu.classList.contains('active')) {
                const firstLink = mobileMenu.querySelector('.mobile-nav-link');
                if (firstLink) firstLink.focus();
            }
        });

// loading page handling 

        window.addEventListener("DOMContentLoaded", () => {
        document.getElementById("container").style.display = "none"
        document.getElementById("content").style.display = "block"
        })