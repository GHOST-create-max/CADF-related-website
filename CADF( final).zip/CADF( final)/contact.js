
        // Menu mobile uniquement - JavaScript minimal
        const hamburger = document.getElementById('hamburger');
        const mobileMenu = document.getElementById('mobileMenu');
        const mobileOverlay = document.getElementById('mobileOverlay');

        function toggleMobileMenu() {
            hamburger.classList.toggle('active');
            mobileMenu.classList.toggle('active');
            mobileOverlay.classList.toggle('active');
            document.body.style.overflow = mobileMenu.classList.contains('active') ? 'hidden' : '';
        }

        function closeMobileMenu() {
            hamburger.classList.remove('active');
            mobileMenu.classList.remove('active');
            mobileOverlay.classList.remove('active');
            document.body.style.overflow = '';
        }

        // Event listeners essentiels
        hamburger.addEventListener('click', toggleMobileMenu);
        mobileOverlay.addEventListener('click', closeMobileMenu);

        // Fermer le menu mobile au clic sur un lien
        document.querySelectorAll('.mobile-nav-link').forEach(link => {
            link.addEventListener('click', closeMobileMenu);
        });

        // Fermer le menu mobile sur redimensionnement
        window.addEventListener('resize', () => {
            if (window.innerWidth > 768) {
                closeMobileMenu();
            }
        });
        
         //changement de theme
         
 
        // les constantes 
        const btn= document.getElementById("theme-btn")
        const sun = document.getElementById("sun")
        const moon = document.getElementById("moon")
        const sauvegarde = localStorage.getItem('theme')
        
        // chargement du theme sauvegardee
        if (sauvegarde == 'dark') {
            document.documentElement.classList.add('dark')
            sun.style.display = "none"
            moon.style.display = 'inline'
        }else {
            sun.style.display = 'inline'
            moon.style.display = 'none'
               
        
            
        }
        
       // toggle de la classe dark et changement d'icones 
       btn.addEventListener("click", () => {
           if (document.documentElement.classList.contains("dark")) {
               document.documentElement.classList.remove("dark")
               sun.style.display = 'inline'
               moon.style.display = 'none'
               localStorage.setItem('theme', 'light')
           }else {
               document.documentElement.classList.add("dark")
               sun.style.display = "none"
               moon.style.display = 'inline'
               localStorage.setItem('theme', 'dark')
           }
           
           })

     

        // Gestion simple du formulaire
        const contactForm = document.getElementById('contactForm');
        if (contactForm) {
            contactForm.addEventListener('submit', function(e) {
                e.preventDefault();
                
                // Validation simple
                const requiredFields = this.querySelectorAll('[required]');
                let isValid = true;
                
                requiredFields.forEach(field => {
                    if (!field.value.trim()) {
                        field.style.borderColor = '#e74c3c';
                        isValid = false;
                    } else {
                        field.style.borderColor = 'var(--border-color)';
                    }
                });
                
                if (!isValid) {
                    alert('Veuillez remplir tous les champs obligatoires.');
                    return;
                }
                
                // Feedback utilisateur
                const button = this.querySelector('.form-button');
                const originalText = button.textContent;
                const originalBg = button.style.background;
                
                button.textContent = 'Message envoyé avec succès ✓';
                button.style.background = '#27ae60';
                button.disabled = true;
                
                // Simuler l'envoi et reset
                setTimeout(() => {
                    button.textContent = originalText;
                    button.style.background = originalBg || 'var(--accent-cta)';
                    button.disabled = false;
                    this.reset();
                    
                    // Message de confirmation
                    const confirmation = document.createElement('div');
                    confirmation.style.cssText = `
                        position: fixed;
                        top: 100px;
                        right: 20px;
                        background: var(--accent-cta);
                        color: var(--bg-secondary);
                        padding: 1rem 2rem;
                        border-radius: 10px;
                        font-weight: 600;
                        z-index: 1001;
                        box-shadow: var(--shadow);
                        animation: slideInRight 0.3s ease-out;
                    `;
                    confirmation.textContent = 'Message reçu ! Nous vous répondrons sous 24h.';
                    document.body.appendChild(confirmation);
                    
                    setTimeout(() => {
                        confirmation.remove();
                    }, 5000);
                }, 2000);
            });
        }

        // Animation slide pour la notification
        const style = document.createElement('style');
        style.textContent = `
            @keyframes slideInRight {
                from {
                    transform: translateX(100%);
                    opacity: 0;
                }
                to {
                    transform: translateX(0);
                    opacity: 1;
                }
            }
        `;
        document.head.appendChild(style);

        // Amélioration UX : focus sur premier champ au chargement
        document.addEventListener('DOMContentLoaded', function() {
            const firstInput = document.getElementById('firstName');
            if (firstInput) {
                // Focus après un délai pour éviter le scroll automatique
                setTimeout(() => {
                    firstInput.focus();
                }, 500);
            }
        });

        // Sauvegarde automatique des données du formulaire (localStorage)
        const formFields = ['firstName', 'lastName', 'email', 'phone', 'subject'];
        
        // Charger les données sauvegardées
        formFields.forEach(fieldId => {
            const field = document.getElementById(fieldId);
            const savedValue = localStorage.getItem(`contact_${fieldId}`);
            if (field && savedValue) {
                field.value = savedValue;
            }
        });

        // Sauvegarder au fur et à mesure
        formFields.forEach(fieldId => {
            const field = document.getElementById(fieldId);
            if (field) {
                field.addEventListener('input', function() {
                    localStorage.setItem(`contact_${fieldId}`, this.value);
                });
            }
        });

        // Nettoyer le localStorage après envoi réussi
        if (contactForm) {
            contactForm.addEventListener('submit', function() {
                setTimeout(() => {
                    formFields.forEach(fieldId => {
                        localStorage.removeItem(`contact_${fieldId}`);
                    });
                }, 2000);
            });
        }

        // Amélioration accessibilité : gestion clavier pour les cartes
        document.querySelectorAll('.contact-card, .team-card').forEach(card => {
            card.setAttribute('tabindex', '0');
            card.addEventListener('keydown', function(e) {
                if (e.key === 'Enter' || e.key === ' ') {
                    const link = this.querySelector('a');
                    if (link) {
                        link.click();
                    }
                }
            });
        });
